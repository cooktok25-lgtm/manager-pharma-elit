'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { api, auth } from '@/lib/api';
import Sidebar from '@/components/Sidebar';

export default function CertificationPage() {
  const router = useRouter();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [issuing, setIssuing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    try {
      const d = await api.eligibility();
      setData(d);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!auth.getToken()) {
      router.replace('/login');
      return;
    }
    load();
  }, [router]);

  const handleIssue = async () => {
    setIssuing(true);
    try {
      await api.issueCertificate();
      await load();
    } catch (e: any) {
      alert(e.message);
    } finally {
      setIssuing(false);
    }
  };

  const downloadPdf = async (certId: string) => {
    // Le PDF nécessite le JWT en header → on fetch + download via blob
    const token = auth.getToken();
    try {
      const res = await fetch(api.certificatePdfUrl(certId), {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error('Téléchargement échoué');
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `certificat-medleader.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (e: any) {
      alert(e.message);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-ink/60">
        Chargement...
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar />
      <main className="flex-1 px-4 md:px-10 py-6 md:py-8 max-w-3xl">
        <Link href="/dashboard" className="text-sm text-copper hover:underline">
          ← Retour au tableau de bord
        </Link>

        <div className="mt-4 mb-8 pb-6 border-b border-border">
          <div className="text-[10px] uppercase tracking-widest text-copper mb-2">
            — Validation finale
          </div>
          <h1 className="font-serif text-3xl md:text-5xl">Votre certification</h1>
          <p className="text-ink/60 mt-2 text-sm max-w-xl">
            La certification est délivrée automatiquement quand vous remplissez les
            critères ci-dessous. Le certificat est généré au format PDF avec une
            signature de vérification.
          </p>
        </div>

        {error && (
          <div className="mb-4 px-4 py-3 bg-copper/10 text-copper text-sm rounded">
            {error}
          </div>
        )}

        {/* Critères */}
        <div className="mb-8">
          <h2 className="font-serif text-xl mb-4">Critères d'éligibilité</h2>
          <div className="space-y-2">
            {data?.requirements.map((r: any) => (
              <div
                key={r.key}
                className={`bg-cream border p-4 flex items-center justify-between gap-3 ${
                  r.ok ? 'border-forest/40' : 'border-border'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center text-xs shrink-0 ${
                      r.ok
                        ? 'bg-forest text-paper'
                        : 'bg-border text-ink/60'
                    }`}
                  >
                    {r.ok ? '✓' : '·'}
                  </div>
                  <div className="font-serif text-base">{r.label}</div>
                </div>
                <div className="text-right shrink-0">
                  <div className="font-mono text-sm">
                    <span className={r.ok ? 'text-forest font-bold' : 'text-ink/60'}>
                      {r.current}
                    </span>
                    <span className="text-ink/40"> / {r.required}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Action principale */}
        {data?.existing ? (
          <div className="bg-ink text-paper p-6 mb-6">
            <div className="text-[10px] uppercase tracking-widest text-copper mb-2">
              ✓ Certificat émis
            </div>
            <div className="font-serif text-2xl mb-1">
              N° {data.existing.certificateNo}
            </div>
            <div className="text-sm text-paper/70 mb-4">
              Émis le{' '}
              {new Date(data.existing.issuedAt).toLocaleDateString('fr-FR', {
                day: 'numeric',
                month: 'long',
                year: 'numeric',
              })}{' '}
              · Score final {data.existing.globalScore}/100
            </div>
            <button
              onClick={() => downloadPdf(data.existing.id)}
              className="bg-copper text-paper px-5 py-3 rounded font-medium hover:bg-copper/90 transition"
            >
              ⬇ Télécharger le certificat (PDF)
            </button>
          </div>
        ) : data?.eligible ? (
          <button
            onClick={handleIssue}
            disabled={issuing}
            className="w-full bg-forest text-paper py-4 rounded font-medium hover:bg-forest/90 transition disabled:opacity-50"
          >
            {issuing ? 'Émission en cours...' : '🎓 Émettre mon certificat maintenant'}
          </button>
        ) : (
          <div className="bg-cream border border-border p-5 text-center">
            <p className="text-sm text-ink/70">
              Vous n'êtes pas encore éligible. Continuez votre parcours pour valider
              les critères ci-dessus.
            </p>
            <div className="flex gap-2 justify-center mt-4">
              <Link
                href="/dashboard"
                className="px-4 py-2 border border-ink rounded text-sm hover:bg-ink hover:text-paper transition"
              >
                Voir mes modules
              </Link>
              <Link
                href="/simulation"
                className="px-4 py-2 bg-ink text-paper rounded text-sm hover:bg-ink/90 transition"
              >
                Lancer une simulation
              </Link>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
