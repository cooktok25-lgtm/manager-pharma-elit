# MedLeader — MVP SaaS Formation IA pour managers pharma

> Plateforme de formation, simulation, évaluation et certification IA pour les délégués médicaux et pharmaceutiques en mobilité vers le management.

## ⚡ TL;DR — Démarrage en 1 commande (Docker)

```bash
# Optionnel : activer la vraie IA (sinon mode démo)
export ANTHROPIC_API_KEY="sk-ant-xxxxx"

# Tout démarrer
docker-compose up --build
```

Ouvrir **http://localhost:3000** et se connecter :
- **test@medleader.com** / **password123**

3 services se lancent automatiquement :
- 🐘 PostgreSQL 16 (port 5432)
- ⚙️ Backend NestJS (port 4000) — applique les migrations Prisma + seed au boot
- 🎨 Frontend Next.js (port 3000)

---

## 🛠️ Démarrage manuel (sans Docker)

```bash
# 1. PostgreSQL via Docker
docker-compose up -d postgres

# 2. Backend
cd backend
cp .env.example .env
# → édite .env et ajoute ta clé ANTHROPIC_API_KEY (sinon mode démo)
npm install
npm run db:setup        # génère client + migre + seed
npm run start:dev       # http://localhost:4000

# 3. Frontend (nouveau terminal)
cd frontend
cp .env.local.example .env.local
npm install
npm run dev             # http://localhost:3000
```

---

## 🧱 Stack technique

| Couche | Techno |
|--------|--------|
| Frontend | Next.js 14 (App Router) + TypeScript + Tailwind CSS |
| Backend | NestJS 10 + TypeScript |
| Base de données | PostgreSQL 16 |
| ORM | Prisma 5 |
| Auth | JWT (Passport) + bcryptjs |
| IA | Anthropic Claude (SDK officiel) |
| PDF | PDFKit (génération certificats) |

---

## 📂 Structure

```
medleader-mvp/
├── docker-compose.yml          # Orchestre les 3 services
├── README.md
│
├── backend/                    # API NestJS
│   ├── Dockerfile              # Multi-stage Node 20 alpine
│   ├── prisma/
│   │   ├── schema.prisma       # 8 modèles (User, Module, Quiz, Scenario, Session, Message, Certification, Progress)
│   │   └── seed.ts             # données de test
│   └── src/
│       ├── main.ts, app.module.ts
│       ├── prisma/             # service Prisma global
│       ├── auth/               # register / login / JWT / bcryptjs
│       ├── users/
│       ├── modules/            # LMS : modules + quiz
│       ├── simulation/         # ⭐ chat IA + analyse multi-axes
│       ├── dashboard/          # KPIs agrégés
│       └── certification/      # ⭐ éligibilité + émission + PDF
│
└── frontend/                   # App Next.js
    ├── Dockerfile              # Multi-stage Next.js
    └── src/
        ├── app/
        │   ├── login/, register/
        │   ├── dashboard/      # progression + KPIs + scores
        │   ├── module/[id]/    # contenu markdown + quiz
        │   ├── simulation/     # ⭐ chat IA temps réel
        │   └── certification/  # ⭐ critères + PDF
        ├── components/Sidebar.tsx
        └── lib/api.ts          # fetch wrapper + JWT
```

---

## 🎯 Fonctionnalités

### ✅ 1. Authentification
Inscription avec choix d'objectif, connexion, JWT en localStorage, routes protégées.

### ✅ 2. Dashboard
Progression %, score global, scores par axe (leadership / communication / décision), liste modules avec statut, historique simulations.

### ✅ 3. Module de formation
1 module seedé : "Leadership de proximité" (Niveau 1, 45 min, 4 questions). Contenu markdown rendu inline. Quiz validé à ≥ 70/100.

### ✅ 4. Simulation IA — cœur du produit
Scénario : "Recadrer un délégué en sous-performance". L'IA joue Karim Bensaïd (-32% CA) avec un contexte caché (burn-out de sa femme). Karim s'ouvre uniquement si vraie écoute, se ferme si pression. Toutes les interactions persistées.

### ✅ 5. Analyse IA après chaque réponse
**Deux appels Claude en parallèle** par message utilisateur :
1. Role-play (le personnage répond)
2. Évaluation par un "directeur régional" : note sur 10 + feedback + scores par axe

Sortie JSON structurée. Affichage en accordéon sous chaque message. Mise à jour automatique des scores agrégés.

### ✅ 6. Certification — génération PDF réelle
3 critères d'éligibilité : modules complétés, simulations réalisées, score moyen ≥ 7/10. Bouton d'émission quand éligible → numéro unique (ML-XXXXXXXX) + signature HMAC. **PDF A4 paysage généré à la volée par PDFKit** (couleurs et typographie cohérentes avec le frontend). Téléchargement avec auth JWT (blob fetch).

---

## 🔑 Configuration de l'IA

```env
# Dans backend/.env (ou via variable d'env Docker)
ANTHROPIC_API_KEY="sk-ant-xxxxxxxxxxxxx"
ANTHROPIC_MODEL="claude-sonnet-4-20250514"
```

🆓 **Sans clé API** : mode démo avec réponses simulées. L'app reste utilisable de bout en bout.

📝 Obtenir une clé : https://console.anthropic.com/

---

## 🚀 Endpoints API (sous `/api/v1`)

### Auth
- `POST /auth/register` — `{ email, password, firstName, lastName, goal? }`
- `POST /auth/login` — `{ email, password }`
- `GET /auth/me` 🔒

### Dashboard
- `GET /dashboard` 🔒 — vue agrégée (KPIs, skills, sessions récentes)

### Modules (LMS)
- `GET /modules` 🔒
- `GET /modules/:id` 🔒
- `POST /modules/:id/quiz` 🔒 — `{ answers: [{ questionId, optionIndex }] }`

### Simulation
- `GET /simulation/scenarios` 🔒
- `POST /simulation/start` 🔒 — `{ scenarioId }`
- `GET /simulation/sessions/:id` 🔒
- `POST /simulation/sessions/:id/message` 🔒 — `{ content }` → renvoie `{ userMessage (avec score+axes+feedback), aiMessage }`
- `POST /simulation/sessions/:id/end` 🔒

### Certification
- `GET /certifications/eligibility` 🔒 — `{ eligible, requirements[], existing }`
- `POST /certifications/issue` 🔒 — émet le certificat si éligible
- `GET /certifications/:id/pdf` 🔒 — renvoie le PDF en `Content-Disposition: attachment`

🔒 = nécessite `Authorization: Bearer <jwt>`

---

## 🗄️ Schéma de données

```
User ──┬── ModuleProgress ──► Module ──► QuizQuestion
       ├── SimulationSession ──► Scenario
       │           │
       │           └── SimulationMessage (role, content, score, feedback, axes JSON)
       └── Certification (certificateNo, globalScore, signatureHash HMAC)
```

Voir `backend/prisma/schema.prisma` pour le détail.

---

## 🧪 Données seedées

| Type | Détail |
|------|--------|
| 👤 User | `test@medleader.com` / `password123` (Marie Dupont, manager) |
| 📚 Module | "Leadership de proximité" (4 questions) |
| 🎭 Scenario | "Recadrer un délégué en sous-performance" (Karim, -32% CA, contexte caché de burn-out familial) |

---

## 🌐 Déploiement production

### Option A : Backend Railway + Frontend Vercel

**Backend (Railway)**
1. `railway login && railway init`
2. `railway add postgresql`
3. Variables d'env :
   - `DATABASE_URL` (auto)
   - `JWT_SECRET=$(openssl rand -hex 32)`
   - `ANTHROPIC_API_KEY=sk-ant-xxx`
   - `ANTHROPIC_MODEL=claude-sonnet-4-20250514`
   - `CORS_ORIGIN=https://votre-frontend.vercel.app`
4. **Build** : `npm install && npm run prisma:generate && npm run build`
5. **Start** : `npm run prisma:deploy && npm run start:prod`
6. Premier deploy : `railway run npm run prisma:seed`

**Frontend (Vercel)**
1. `cd frontend && vercel`
2. Variable d'env : `NEXT_PUBLIC_API_URL=https://votre-backend.railway.app/api/v1`

### Option B : Tout sur un VPS avec Docker Compose

```bash
git clone <votre-repo>
cd medleader-mvp
echo "ANTHROPIC_API_KEY=sk-ant-xxx" > .env
echo "JWT_SECRET=$(openssl rand -hex 32)" >> .env
docker-compose up -d --build
# Mettre Caddy ou Traefik en reverse proxy pour HTTPS
```

---

## 🧠 Comment fonctionne l'IA exactement

À chaque message utilisateur dans une simulation, le backend lance **deux appels Claude en parallèle** (`Promise.all` dans `simulation.service.ts`) :

### Appel 1 — Role-play
```ts
llm.generateRolePlayReply(scenario.systemPrompt, conversationHistory)
```
Le `systemPrompt` définit le personnage (Karim, son contexte caché, ses règles de comportement). L'historique complet est passé pour la cohérence narrative.

### Appel 2 — Analyse
```ts
llm.analyzeUserResponse(scenarioContext, conversationSoFar, userMessage)
```
Claude joue ici un "directeur régional pharmaceutique expérimenté". Il évalue la dernière réponse du manager sur 3 axes. Output JSON strict avec validation Zod-like et fallback sécurisé en cas d'erreur de parsing.

Les deux résultats sont persistés en DB et renvoyés au frontend en une seule réponse.

---

## ⚙️ Commandes utiles

```bash
# Backend
cd backend
npm run prisma:generate
npm run prisma:migrate -- --name nom_migration
npm run prisma:seed
npx prisma studio              # GUI DB

# Frontend
cd frontend
npm run build
npm run start

# Docker
docker-compose up               # démarrage attaché
docker-compose up -d            # détaché
docker-compose logs -f backend  # suivre les logs
docker-compose down -v          # tout arrêter + supprimer données
docker-compose build --no-cache # rebuild propre
```

---

## ⚠️ Sécurité — checklist avant production

- [ ] Remplacer `JWT_SECRET` par `openssl rand -hex 32`
- [ ] Restreindre `CORS_ORIGIN` au domaine frontend uniquement
- [ ] HTTPS (Vercel/Railway auto, sinon Caddy/Traefik en reverse proxy)
- [ ] Migrer le storage du JWT vers httpOnly cookies (au lieu de localStorage)
- [ ] Rate limiting (`@nestjs/throttler` + Redis)
- [ ] DPA signé avec Anthropic
- [ ] Sentry pour les erreurs runtime
- [ ] Backups PostgreSQL automatiques

---

## 📌 Limites connues du MVP

- Pas de WebSocket : les réponses IA arrivent en bloc (latence 3-8s). Streaming token-par-token = chantier futur.
- 1 seul scénario seedé. L'architecture supporte N scénarios sans modif.
- Pas de gestion multi-organisation (B2B). Le schéma le supporte facilement.
- Pas de tests automatisés. À ajouter (Vitest + Supertest + Playwright).

---

## ✅ Validation

Tout a été type-checké et compilé avec succès :
- Backend : `tsc --noEmit` 0 erreur, `npm run build` produit `dist/main.js`, NestJS boot OK
- Frontend : `tsc --noEmit` 0 erreur, `next build` génère 8 routes (87-98 kB First Load JS)
- PDFKit : génération PDF testée (sortie valide)
