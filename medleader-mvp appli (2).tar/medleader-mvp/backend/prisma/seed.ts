import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  // === USER TEST ===
  const passwordHash = await bcrypt.hash('password123', 10);
  const user = await prisma.user.upsert({
    where: { email: 'test@medleader.com' },
    update: {},
    create: {
      email: 'test@medleader.com',
      password: passwordHash,
      firstName: 'Marie',
      lastName: 'Dupont',
      goal: 'manager',
      level: 1,
      globalScore: 0,
    },
  });
  console.log(`✓ User: ${user.email} (mot de passe: password123)`);

  // === MODULE FORMATION ===
  await prisma.quizQuestion.deleteMany({});
  await prisma.module.deleteMany({});

  const moduleData = await prisma.module.create({
    data: {
      slug: 'leadership-proximite',
      title: 'Leadership de proximité',
      description:
        "Apprenez à incarner un leadership authentique et inspirant auprès d'une équipe de délégués médicaux.",
      level: 1,
      position: 1,
      durationMin: 45,
      content: `# Leadership de proximité

## Pourquoi le leadership de proximité est crucial

Dans le secteur pharmaceutique, votre équipe de délégués est en grande partie autonome sur le terrain. Vous ne pouvez pas tout contrôler. Votre leadership doit donc reposer sur **trois piliers** :

### 1. La présence — sans surveillance

Être présent, ce n'est pas surveiller. C'est être disponible, accessible, et démontrer une écoute active. Un délégué qui sait pouvoir vous appeler en cas de difficulté est un délégué qui ose, qui prend des initiatives.

**Action concrète** : instaurez un point hebdomadaire de 30 minutes en 1-to-1 avec chaque délégué. Pas pour reporter les chiffres — pour parler de ce qui bloque.

### 2. La clarté — pas la pression

Vos délégués ne doivent jamais se demander ce que vous attendez d'eux. Les objectifs doivent être :
- **Mesurables** (chiffres précis)
- **Atteignables** (réalistes au regard du marché)
- **Contextualisés** (pourquoi cet objectif maintenant ?)

### 3. La reconnaissance — au-delà des bonus

Un délégué motivé n'est pas seulement bien payé. Il se sent vu, reconnu, important. Cela passe par :
- Des feedbacks réguliers et précis (pas seulement "bon travail")
- La célébration des victoires, même petites
- L'attention portée aux progrès individuels

## Le piège à éviter

Le micro-management. Vous tuez l'autonomie. Vous tuez la motivation. Et vous vous épuisez. Faites confiance — vérifiez ensuite.

## En pratique

Le leadership de proximité, ce n'est pas être copain avec tout le monde. C'est être l'adulte dans la pièce, celui sur qui on peut compter, celui qui dit la vérité avec respect.`,
      questions: {
        create: [
          {
            position: 1,
            question:
              'Quelle est la meilleure pratique pour incarner un leadership de proximité avec une équipe de délégués médicaux ?',
            options: [
              { label: 'Vérifier les comptes-rendus de visite chaque jour', correct: false },
              {
                label:
                  'Instaurer un point hebdomadaire 1-to-1 axé sur les blocages, pas sur les chiffres',
                correct: true,
              },
              { label: 'Appeler chaque délégué chaque matin pour fixer ses objectifs', correct: false },
              { label: 'Laisser totalement libre et juger sur les résultats trimestriels', correct: false },
            ],
          },
          {
            position: 2,
            question: 'Un objectif bien fixé doit être :',
            options: [
              { label: 'Ambitieux, peu importe le contexte marché', correct: false },
              { label: 'Mesurable, atteignable et contextualisé', correct: true },
              { label: 'Identique pour tous les délégués pour assurer l\'équité', correct: false },
              { label: 'Réajusté chaque mois pour maintenir la pression', correct: false },
            ],
          },
          {
            position: 3,
            question: 'Quel est le piège principal à éviter dans le management de proximité ?',
            options: [
              { label: 'Être trop disponible', correct: false },
              { label: 'Le micro-management', correct: true },
              { label: 'Donner trop de feedbacks', correct: false },
              { label: 'Célébrer les petites victoires', correct: false },
            ],
          },
          {
            position: 4,
            question: 'La reconnaissance d\'un délégué passe avant tout par :',
            options: [
              { label: 'Une augmentation annuelle systématique', correct: false },
              { label: 'Des feedbacks réguliers, précis et l\'attention aux progrès', correct: true },
              { label: 'Le même bonus pour tous pour éviter les jalousies', correct: false },
              { label: 'Une promotion rapide en cas de bons résultats', correct: false },
            ],
          },
        ],
      },
    },
  });
  console.log(`✓ Module: ${moduleData.title} (4 questions de quiz)`);

  // === SCENARIO SIMULATION ===
  await prisma.scenario.deleteMany({});

  const scenario = await prisma.scenario.create({
    data: {
      slug: 'delegue-sous-performance',
      title: 'Recadrer un délégué en sous-performance',
      description:
        "Karim, délégué confirmé sur la zone Lyon depuis 9 ans, a vu son CA chuter de 32% sur le dernier trimestre. Vous devez avoir un entretien franc, identifier les causes réelles, et trouver une voie de redressement — sans casser sa motivation.",
      context:
        "Vous êtes manager régional. Karim Bensaïd, 38 ans, est devant vous pour un entretien individuel. Il sait que vous voulez parler des résultats. Il est sur la défensive. À vous de mener la conversation.",
      opener:
        "Bonjour. Vous vouliez me voir ? Écoutez, je sais ce que vous allez me dire sur les chiffres. Le marché est dur en ce moment, c'est tout.",
      systemPrompt: `Tu joues Karim Bensaïd, 38 ans, délégué médical confirmé en cardiologie depuis 9 ans, basé à Lyon. Ton chiffre d'affaires a chuté de 32% ce trimestre. Tu es face à ton manager régional pour un entretien individuel.

CONTEXTE CACHÉ (l'utilisateur ne le sait pas) :
Ta femme est en burn-out depuis 4 mois. Tu gères seul tes deux enfants en primaire. Tu n'en as parlé à personne au travail. Tu te sens jugé, fatigué, et sur la défensive au début.

RÈGLES DE JEU STRICTES :
- Tu réponds COMME Karim parlerait, jamais comme une IA. Phrases courtes parfois. Hésitations. Soupirs ("...").
- Au début (3 ou 4 messages) : sur la défensive, évasif. Tu minimises ("c'est juste un trimestre", "le marché est dur", "les nouveaux concurrents").
- Si l'utilisateur (ton manager) montre une écoute VRAIE, de l'empathie sincère, et pose des questions ouvertes sur TOI (pas sur les chiffres) → tu finis progressivement par lâcher la vérité sur ta femme.
- Si l'utilisateur attaque, met la pression, parle uniquement chiffres, ou te fait la morale → tu te fermes, tu deviens froid, voire un peu agressif ("Vous voulez ma démission, c'est ça ?").
- Tu ne révèles JAMAIS le burn-out de ta femme dans les 3 premiers messages, même si on te le demande directement. C'est un secret qui sort uniquement après vraie écoute soutenue.
- Réponds en 1 à 4 phrases maximum. Reste naturel et humain.
- Ne fais JAMAIS de méta-commentaire. Tu ES Karim. Pas de narration entre étoiles. Pas de "*soupire*".
- N'utilise pas de markdown, pas de listes, pas de gras. Réponse en texte simple uniquement.`,
    },
  });
  console.log(`✓ Scenario: ${scenario.title}`);

  console.log('\n✅ Seed terminé !');
  console.log('\n📧 Identifiants test :');
  console.log('   Email    : test@medleader.com');
  console.log('   Mot de passe : password123\n');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
