'use client';

import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { api, auth } from '@/lib/api';
import Sidebar from '@/components/Sidebar';

type Message = {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  score?: number;
  feedback?: string;
  axes?: { leadership: number; communication: number; decision: number };
};

export default function SimulationPage() {
  const router = useRouter();
  const [scenarios, setScenarios] = useState<any[]>([]);
  const [session, setSession] = useState<any>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [starting, setStarting] = useState(false);
  const [showFeedback, setShowFeedback] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!auth.getToken()) {
      router.replace('/login');
      return;
    }
    api.scenarios().then(setScenarios as any);
  }, [router]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, sending]);

  const startSession = async (scenarioId: string) => {
    setStarting(true);
    try {
      const s: any = await api.startSimulation(scenarioId);
      setSession(s);
      setMessages(s.messages);
    } catch (e: any) {
      alert(e.message);
    } finally {
      setStarting(false);
    }
  };

  const sendMessage = async () => {
    if (!input.trim() || sending) return;
    const userText = input.trim();
    setInput('');
    setSending(true);

    // Optimistic UI
    const tempId = 'temp-' + Date.now();
    setMessages((prev) => [
      ...prev,
      { id: tempId, role: 'user', content: userText },
    ]);

    try {
      const res: any = await api.sendMessage(session.id, userText);
      // Remplace le message temporaire par le vrai (avec analyse) + ajoute la réponse IA
      setMessages((prev) => {
        const filtered = prev.filter((m) => m.id !== tempId);
        return [...filtered, res.userMessage, res.aiMessage];
      });
    } catch (e: any) {
      setMessages((prev) => [
        ...prev.filter((m) => m.id !== tempId),
        {
          id: 'err-' + Date.now(),
          role: 'assistant',
          content: '⚠️ Erreur : ' + e.message,
        },
      ]);
    } finally {
      setSending(false);
    }
  };

  const endSession = async () => {
    if (!session) return;
    if (!confirm('Terminer cette simulation ?')) return;
    await api.endSession(session.id);
    setSession(null);
    setMessages([]);
  };

  // === ÉCRAN 1 : sélection scénario ===
  if (!session) {
    return (
      <div className="min-h-screen flex flex-col md:flex-row">
        <Sidebar />
        <main className="flex-1 px-4 md:px-10 py-6 md:py-8 max-w-4xl">
          <div className="mb-8 pb-6 border-b border-border">
            <div className="text-[10px] uppercase tracking-widest text-copper mb-2">
              — Laboratoire de simulation IA
            </div>
            <h1 className="font-serif text-3xl md:text-5xl">Choisissez un scénario</h1>
            <p className="text-ink/60 mt-2 text-sm">
              L'IA joue un personnage. Vos réponses sont analysées en temps réel sur 3 axes.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {scenarios.map((sc) => (
              <button
                key={sc.id}
                onClick={() => startSession(sc.id)}
                disabled={starting}
                className="text-left bg-cream border border-border p-6 hover:border-ink transition group disabled:opacity-50"
              >
                <div className="text-[10px] uppercase tracking-widest text-copper mb-2">
                  Scénario
                </div>
                <h3 className="font-serif text-2xl mb-2 group-hover:text-forest transition">
                  {sc.title}
                </h3>
                <p className="text-sm text-ink/70 mb-3">{sc.description}</p>
                <p className="text-xs text-ink/60 italic">{sc.context}</p>
                <div className="mt-4 flex items-center text-sm text-copper font-medium">
                  {starting ? 'Démarrage...' : 'Lancer la simulation →'}
                </div>
              </button>
            ))}
            {scenarios.length === 0 && (
              <p className="text-ink/60">Aucun scénario disponible.</p>
            )}
          </div>
        </main>
      </div>
    );
  }

  // === ÉCRAN 2 : chat de simulation ===
  const lastUserMsg = [...messages].reverse().find((m) => m.role === 'user' && m.score != null);

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar />
      <main className="flex-1 flex flex-col h-screen">
        {/* Header simulation */}
        <header className="bg-cream border-b border-border px-4 md:px-8 py-4 flex items-center justify-between gap-3 shrink-0">
          <div className="min-w-0">
            <div className="text-[10px] uppercase tracking-wider text-copper">
              Simulation en cours
            </div>
            <div className="font-serif text-base md:text-lg truncate">
              {session.scenario.title}
            </div>
          </div>
          <button
            onClick={endSession}
            className="text-xs px-3 py-1.5 border border-ink rounded hover:bg-ink hover:text-paper transition shrink-0"
          >
            Terminer
          </button>
        </header>

        {/* Contexte */}
        <div className="px-4 md:px-8 py-3 bg-paper border-b border-border text-xs text-ink/70 italic shrink-0">
          {session.scenario.context}
        </div>

        {/* Conversation */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 md:px-8 py-6">
          <div className="max-w-2xl mx-auto space-y-4">
            {messages.map((msg) => (
              <div key={msg.id}>
                <div
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[85%] px-4 py-3 rounded text-sm leading-relaxed whitespace-pre-wrap ${
                      msg.role === 'user'
                        ? 'bg-ink text-paper'
                        : 'bg-cream border border-border text-ink'
                    }`}
                  >
                    {msg.content}
                  </div>
                </div>

                {/* Analyse IA sous chaque message user */}
                {msg.role === 'user' && msg.score != null && (
                  <div className="flex justify-end mt-2">
                    <div className="max-w-[85%] bg-paper border border-copper/30 rounded p-3">
                      <button
                        onClick={() =>
                          setShowFeedback(showFeedback === msg.id ? null : msg.id)
                        }
                        className="w-full flex items-center justify-between text-xs"
                      >
                        <div className="flex items-center gap-2">
                          <span
                            className={`font-mono font-bold text-base ${
                              msg.score >= 7
                                ? 'text-forest'
                                : msg.score >= 4
                                ? 'text-copper'
                                : 'text-red-700'
                            }`}
                          >
                            {msg.score}/10
                          </span>
                          <span className="text-ink/60 uppercase tracking-wider">
                            Analyse IA
                          </span>
                        </div>
                        <span className="text-ink/60">
                          {showFeedback === msg.id ? '▲' : '▼'}
                        </span>
                      </button>

                      {showFeedback === msg.id && (
                        <div className="mt-3 pt-3 border-t border-border space-y-2">
                          <p className="text-xs text-ink leading-relaxed">{msg.feedback}</p>
                          {msg.axes && (
                            <div className="grid grid-cols-3 gap-2 mt-2">
                              {(['leadership', 'communication', 'decision'] as const).map(
                                (k) => (
                                  <div key={k} className="bg-cream p-2 rounded">
                                    <div className="text-[9px] uppercase tracking-wider text-ink/60">
                                      {k === 'decision' ? 'Décision' : k}
                                    </div>
                                    <div className="font-mono text-sm font-bold">
                                      {msg.axes![k]}/10
                                    </div>
                                  </div>
                                ),
                              )}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            ))}

            {sending && (
              <div className="flex justify-start">
                <div className="bg-cream border border-border rounded px-4 py-3 text-xs text-ink/60 italic">
                  L'IA réfléchit...
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Input */}
        <div className="bg-cream border-t border-border px-4 md:px-8 py-4 shrink-0">
          <div className="max-w-2xl mx-auto">
            <div className="flex gap-2">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendMessage();
                  }
                }}
                placeholder="Votre réponse..."
                rows={2}
                disabled={sending}
                className="flex-1 px-3 py-2.5 bg-paper border border-border rounded text-sm outline-none focus:border-ink resize-none"
              />
              <button
                onClick={sendMessage}
                disabled={sending || !input.trim()}
                className="px-5 bg-ink text-paper rounded font-medium hover:bg-ink/90 transition disabled:opacity-30"
              >
                ↵
              </button>
            </div>
            <div className="flex justify-between mt-1.5 text-[10px] text-ink/50 font-mono">
              <span>↵ envoyer · ⇧↵ retour ligne</span>
              {lastUserMsg && (
                <span>Dernière analyse : {lastUserMsg.score}/10</span>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
