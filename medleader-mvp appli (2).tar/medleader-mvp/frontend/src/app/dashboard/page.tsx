'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { api, auth } from '@/lib/api';
import Sidebar from '@/components/Sidebar';

export default function DashboardPage() {
  const router = useRouter();
  const [data, setData] = useState<any>(null);
  const [modules, setModules] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!auth.getToken()) {
      router.replace('/login');
      return;
    }
    Promise.all([api.dashboard(), api.modules()])
      .then(([d, m]: any) => {
        setData(d);
        setModules(m);
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [router]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-ink/60">
        Chargement...
      </div>
    );
  }
  if (error || !data) {
    return (
      <div className="min-h-screen flex items-center justify-center text-copper">
        Erreur : {error}
      </div>
    );
  }

  const { user, progressionPct, modulesCompleted, modulesTotal, simulationsCount, skills, recentSessions } = data;

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar user={user} />
      <main className="flex-1 px-4 md:px-10 py-6 md:py-8 max-w-5xl">
        {/* Header */}
        <div className="mb-8 pb-6 border-b border-border">
          <div className="text-[10px] text-copper uppercase tracking-widest mb-2">
            — Tableau de bord
          </div>
          <h1 className="font-serif text-3xl md:text-5xl leading-tight">
            Bonjour {user.firstName}.
          </h1>
          <p className="text-ink/60 mt-2 text-sm">
            Objectif :{' '}
            <strong className="text-ink">
              {user.goal === 'manager' ? 'Manager Régional' : 'Directeur Régional'}
            </strong>{' '}
            · Niveau {user.level}
          </p>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-px bg-border mb-8">
          {[
            { label: 'Progression', value: `${progressionPct}%` },
            { label: 'Score global', value: `${user.globalScore}/100` },
            { label: 'Modules', value: `${modulesCompleted}/${modulesTotal}` },
            { label: 'Simulations', value: simulationsCount },
          ].map((kpi, i) => (
            <div key={i} className="bg-cream p-4 md:p-5">
              <div className="text-[10px] uppercase tracking-wider text-ink/60 mb-2">
                {kpi.label}
              </div>
              <div className="font-serif text-3xl md:text-4xl text-ink">{kpi.value}</div>
            </div>
          ))}
        </div>

        {/* Progression bar */}
        <div className="mb-8 bg-cream border border-border p-5">
          <div className="flex justify-between items-center mb-3">
            <h2 className="font-serif text-xl">Progression du parcours</h2>
            <span className="text-sm font-mono text-ink/60">{progressionPct}%</span>
          </div>
          <div className="h-2 bg-border rounded-full overflow-hidden">
            <div
              className="h-full bg-forest transition-all"
              style={{ width: `${progressionPct}%` }}
            />
          </div>
        </div>

        {/* Compétences */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-border mb-8">
          {[
            { key: 'leadership', label: 'Leadership' },
            { key: 'communication', label: 'Communication' },
            { key: 'decision', label: 'Décision' },
          ].map((s) => {
            const v = skills[s.key] || 0;
            return (
              <div key={s.key} className="bg-cream p-5">
                <div className="text-[10px] uppercase tracking-wider text-ink/60 mb-2">
                  {s.label}
                </div>
                <div className="font-serif text-3xl mb-2">
                  {v}<span className="text-sm text-ink/60">/100</span>
                </div>
                <div className="h-1 bg-border rounded-full overflow-hidden">
                  <div
                    className="h-full bg-copper transition-all"
                    style={{ width: `${v}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>

        {/* Modules de formation */}
        <section className="mb-8">
          <h2 className="font-serif text-2xl mb-4">Modules de formation</h2>
          <div className="space-y-2">
            {modules.map((m: any) => (
              <Link
                key={m.id}
                href={`/module/${m.id}`}
                className="block bg-cream border border-border p-4 hover:border-ink transition"
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="text-[10px] uppercase tracking-wider text-copper mb-1">
                      Niveau {m.level} · {m.durationMin} min · {m.questionsCount} questions
                    </div>
                    <div className="font-serif text-lg leading-tight">{m.title}</div>
                    <p className="text-sm text-ink/60 mt-1 line-clamp-2">{m.description}</p>
                  </div>
                  <div className="text-right shrink-0">
                    {m.progress?.status === 'completed' ? (
                      <span className="text-xs bg-forest text-paper px-2 py-1 rounded">
                        ✓ {m.progress.score}/100
                      </span>
                    ) : m.progress?.status === 'in_progress' ? (
                      <span className="text-xs bg-copper text-paper px-2 py-1 rounded">
                        En cours
                      </span>
                    ) : (
                      <span className="text-xs text-ink/60">À démarrer</span>
                    )}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* Sessions récentes */}
        {recentSessions.length > 0 && (
          <section className="mb-8">
            <h2 className="font-serif text-2xl mb-4">Simulations récentes</h2>
            <div className="space-y-2">
              {recentSessions.map((s: any) => (
                <div
                  key={s.id}
                  className="bg-cream border border-border p-4 flex items-center justify-between gap-3"
                >
                  <div>
                    <div className="font-serif text-base">{s.title}</div>
                    <div className="text-xs text-ink/60 mt-0.5">
                      {new Date(s.createdAt).toLocaleString('fr-FR')}
                      {s.status === 'ended' && ' · Terminée'}
                    </div>
                  </div>
                  {s.averageScore != null && (
                    <div className="text-right">
                      <div className="font-serif text-2xl text-forest">
                        {s.averageScore}<span className="text-xs text-ink/60">/10</span>
                      </div>
                      <div className="text-[10px] uppercase tracking-wider text-ink/60">
                        Score moyen
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}

        <Link
          href="/simulation"
          className="block w-full text-center bg-ink text-paper py-4 rounded font-medium hover:bg-ink/90 transition"
        >
          Lancer une nouvelle simulation IA →
        </Link>
      </main>
    </div>
  );
}
