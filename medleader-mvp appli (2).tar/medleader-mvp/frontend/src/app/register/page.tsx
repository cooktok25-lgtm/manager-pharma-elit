'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { api, auth } from '@/lib/api';

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    goal: 'manager',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res: any = await api.register(form);
      auth.setToken(res.accessToken);
      router.replace('/dashboard');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const update = (k: string, v: string) => setForm({ ...form, [k]: v });

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-md">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-10 h-10 bg-ink rounded flex items-center justify-center text-paper font-serif text-xl">
            M
          </div>
          <div>
            <div className="font-serif text-xl">MedLeader</div>
            <div className="text-[10px] text-ink/60 uppercase tracking-wider">
              Académie des managers pharma
            </div>
          </div>
        </div>

        <h1 className="font-serif text-4xl mb-2">Bienvenue.</h1>
        <p className="text-sm text-ink/60 mb-8">
          Créons votre compte en 30 secondes.
        </p>

        <form onSubmit={onSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs uppercase tracking-wider text-ink/60 mb-1.5">
                Prénom
              </label>
              <input
                type="text"
                required
                value={form.firstName}
                onChange={(e) => update('firstName', e.target.value)}
                className="w-full px-3 py-2.5 bg-cream border border-border rounded outline-none focus:border-ink"
              />
            </div>
            <div>
              <label className="block text-xs uppercase tracking-wider text-ink/60 mb-1.5">
                Nom
              </label>
              <input
                type="text"
                required
                value={form.lastName}
                onChange={(e) => update('lastName', e.target.value)}
                className="w-full px-3 py-2.5 bg-cream border border-border rounded outline-none focus:border-ink"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs uppercase tracking-wider text-ink/60 mb-1.5">
              Email
            </label>
            <input
              type="email"
              required
              value={form.email}
              onChange={(e) => update('email', e.target.value)}
              className="w-full px-3 py-2.5 bg-cream border border-border rounded outline-none focus:border-ink"
            />
          </div>
          <div>
            <label className="block text-xs uppercase tracking-wider text-ink/60 mb-1.5">
              Mot de passe (min. 6 caractères)
            </label>
            <input
              type="password"
              required
              minLength={6}
              value={form.password}
              onChange={(e) => update('password', e.target.value)}
              className="w-full px-3 py-2.5 bg-cream border border-border rounded outline-none focus:border-ink"
            />
          </div>
          <div>
            <label className="block text-xs uppercase tracking-wider text-ink/60 mb-1.5">
              Objectif
            </label>
            <select
              value={form.goal}
              onChange={(e) => update('goal', e.target.value)}
              className="w-full px-3 py-2.5 bg-cream border border-border rounded outline-none focus:border-ink"
            >
              <option value="manager">Devenir Manager Régional</option>
              <option value="director">Devenir Directeur Régional</option>
            </select>
          </div>

          {error && (
            <div className="px-3 py-2 bg-copper/10 text-copper text-sm rounded">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-ink text-paper py-3 rounded font-medium hover:bg-ink/90 transition disabled:opacity-50"
          >
            {loading ? 'Création...' : 'Créer mon compte'}
          </button>
        </form>

        <p className="text-sm text-ink/60 mt-6 text-center">
          Déjà un compte ?{' '}
          <Link href="/login" className="text-copper hover:underline">
            Se connecter
          </Link>
        </p>
      </div>
    </div>
  );
}
