import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { SubmitQuizDto } from './dto/quiz.dto';

@Injectable()
export class ModulesService {
  constructor(private prisma: PrismaService) {}

  async listModules(userId: string) {
    const modules = await this.prisma.module.findMany({
      orderBy: [{ level: 'asc' }, { position: 'asc' }],
      include: {
        progress: { where: { userId } },
        _count: { select: { questions: true } },
      },
    });
    return modules.map((m) => ({
      id: m.id,
      slug: m.slug,
      title: m.title,
      description: m.description,
      level: m.level,
      durationMin: m.durationMin,
      questionsCount: m._count.questions,
      progress: m.progress[0]
        ? {
            status: m.progress[0].status,
            score: m.progress[0].score,
            completedAt: m.progress[0].completedAt,
          }
        : null,
    }));
  }

  async getModule(id: string, userId: string) {
    const m = await this.prisma.module.findUnique({
      where: { id },
      include: {
        questions: {
          orderBy: { position: 'asc' },
          // n'expose pas la bonne réponse
          select: { id: true, position: true, question: true, options: true },
        },
        progress: { where: { userId } },
      },
    });
    if (!m) throw new NotFoundException('Module introuvable');

    // Marquer le module comme "in_progress" si pas encore touché
    if (m.progress.length === 0) {
      await this.prisma.moduleProgress.create({
        data: { userId, moduleId: id, status: 'in_progress' },
      });
    }

    // Masquer les flags "correct" dans les options
    const safeQuestions = m.questions.map((q) => ({
      ...q,
      options: (q.options as any[]).map((o: any) => ({ label: o.label })),
    }));

    return {
      id: m.id,
      slug: m.slug,
      title: m.title,
      description: m.description,
      level: m.level,
      content: m.content,
      durationMin: m.durationMin,
      questions: safeQuestions,
      progress: m.progress[0] || null,
    };
  }

  async submitQuiz(moduleId: string, userId: string, dto: SubmitQuizDto) {
    const questions = await this.prisma.quizQuestion.findMany({
      where: { moduleId },
    });
    if (questions.length === 0) throw new NotFoundException('Aucun quiz');

    let correctCount = 0;
    const results = dto.answers.map((a) => {
      const q = questions.find((qq) => qq.id === a.questionId);
      if (!q) return { questionId: a.questionId, correct: false };
      const opts = q.options as any[];
      const chosen = opts[a.optionIndex];
      const correct = chosen?.correct === true;
      if (correct) correctCount++;
      const correctIdx = opts.findIndex((o) => o.correct === true);
      return {
        questionId: a.questionId,
        correct,
        correctOptionIndex: correctIdx,
      };
    });

    const score = Math.round((correctCount / questions.length) * 100);
    const passed = score >= 70;

    await this.prisma.moduleProgress.upsert({
      where: { userId_moduleId: { userId, moduleId } },
      update: {
        status: passed ? 'completed' : 'in_progress',
        score,
        completedAt: passed ? new Date() : null,
      },
      create: {
        userId,
        moduleId,
        status: passed ? 'completed' : 'in_progress',
        score,
        completedAt: passed ? new Date() : null,
      },
    });

    return { score, passed, totalQuestions: questions.length, correctCount, results };
  }
}
