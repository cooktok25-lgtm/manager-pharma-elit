import { Injectable, Logger } from '@nestjs/common';
import Anthropic from '@anthropic-ai/sdk';

interface RolePlayMessage {
  role: 'user' | 'assistant';
  content: string;
}

export interface AnalysisResult {
  score: number;          // 0-10
  feedback: string;       // texte structuré
  axes: {
    leadership: number;
    communication: number;
    decision: number;
  };
}

@Injectable()
export class LlmService {
  private readonly logger = new Logger(LlmService.name);
  private readonly client: Anthropic;
  private readonly model: string;

  constructor() {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      this.logger.warn(
        '⚠️  ANTHROPIC_API_KEY non défini — l\'IA renverra des réponses simulées.',
      );
    }
    this.client = new Anthropic({ apiKey: apiKey || 'dummy-key' });
    this.model = process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-20250514';
  }

  /**
   * Le personnage joué par l'IA répond à l'utilisateur (role-play).
   */
  async generateRolePlayReply(
    systemPrompt: string,
    history: RolePlayMessage[],
  ): Promise<string> {
    if (!process.env.ANTHROPIC_API_KEY) {
      return this.fallbackReply(history);
    }

    try {
      const response = await this.client.messages.create({
        model: this.model,
        max_tokens: 600,
        system: systemPrompt,
        messages: history,
      });

      const text = response.content
        .filter((c) => c.type === 'text')
        .map((c: any) => c.text)
        .join('')
        .trim();

      return text || '...';
    } catch (err: any) {
      this.logger.error(`LLM role-play error: ${err.message}`);
      return this.fallbackReply(history);
    }
  }

  /**
   * L'IA "directeur régional" évalue la dernière réponse de l'utilisateur.
   * Retourne un JSON strict { score, feedback, axes }.
   */
  async analyzeUserResponse(
    scenarioContext: string,
    conversationSoFar: RolePlayMessage[],
    userMessage: string,
  ): Promise<AnalysisResult> {
    if (!process.env.ANTHROPIC_API_KEY) {
      return this.fallbackAnalysis();
    }

    const transcript = conversationSoFar
      .map((m) => `${m.role === 'user' ? 'MANAGER' : 'INTERLOCUTEUR'}: ${m.content}`)
      .join('\n');

    const prompt = `Tu es un directeur régional pharmaceutique expérimenté. Tu évalues un futur manager qui mène une simulation d'entretien difficile.

CONTEXTE DE LA SIMULATION :
${scenarioContext}

CONVERSATION JUSQU'ICI :
${transcript}

DERNIÈRE RÉPONSE DU MANAGER À ÉVALUER :
"${userMessage}"

Analyse cette réponse selon trois axes :
- LEADERSHIP : posture, autorité bienveillante, capacité à cadrer
- COMMUNICATION : clarté, écoute, reformulation, empathie
- DÉCISION : pertinence du choix opérationnel, hiérarchisation

Retourne UNIQUEMENT un objet JSON valide (aucun markdown, aucun backtick, aucun texte avant ou après) avec EXACTEMENT cette structure :
{
  "score": <entier 0-10>,
  "feedback": "<2 à 3 phrases courtes et actionnables, ton de coach senior>",
  "axes": {
    "leadership": <entier 0-10>,
    "communication": <entier 0-10>,
    "decision": <entier 0-10>
  }
}`;

    try {
      const response = await this.client.messages.create({
        model: this.model,
        max_tokens: 500,
        messages: [{ role: 'user', content: prompt }],
      });

      const text = response.content
        .filter((c) => c.type === 'text')
        .map((c: any) => c.text)
        .join('')
        .trim()
        .replace(/```json|```/g, '')
        .trim();

      const parsed = JSON.parse(text);

      // Validation minimale
      const clamp = (n: any, min: number, max: number) =>
        Math.max(min, Math.min(max, Math.round(Number(n) || 0)));

      return {
        score: clamp(parsed.score, 0, 10),
        feedback: String(parsed.feedback || 'Pas de feedback disponible.'),
        axes: {
          leadership: clamp(parsed.axes?.leadership, 0, 10),
          communication: clamp(parsed.axes?.communication, 0, 10),
          decision: clamp(parsed.axes?.decision, 0, 10),
        },
      };
    } catch (err: any) {
      this.logger.error(`LLM analysis error: ${err.message}`);
      return this.fallbackAnalysis();
    }
  }

  // -------- Fallbacks (pas de clé API) --------

  private fallbackReply(history: RolePlayMessage[]): string {
    const lastUser = [...history].reverse().find((m) => m.role === 'user')?.content || '';
    if (lastUser.length < 30)
      return "Je vois... vous avez autre chose à ajouter ? (mode démo : ANTHROPIC_API_KEY non configurée)";
    return "Hmm, je comprends ce que vous me dites. Mais concrètement, vous attendez quoi de moi ? (mode démo)";
  }

  private fallbackAnalysis(): AnalysisResult {
    return {
      score: 6,
      feedback:
        "(Mode démo — analyse simulée) Réponse correcte, posture managériale présente. Configurez ANTHROPIC_API_KEY pour activer l'analyse réelle.",
      axes: { leadership: 6, communication: 6, decision: 6 },
    };
  }
}
