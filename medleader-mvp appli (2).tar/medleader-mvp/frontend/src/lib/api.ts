const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api/v1';
const TOKEN_KEY = 'medleader_token';

export const auth = {
  getToken: (): string | null => {
    if (typeof window === 'undefined') return null;
    return localStorage.getItem(TOKEN_KEY);
  },
  setToken: (token: string) => {
    if (typeof window === 'undefined') return;
    localStorage.setItem(TOKEN_KEY, token);
  },
  clear: () => {
    if (typeof window === 'undefined') return;
    localStorage.removeItem(TOKEN_KEY);
  },
};

async function request<T = any>(path: string, options: RequestInit = {}): Promise<T> {
  const token = auth.getToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...((options.headers as Record<string, string>) || {}),
  };
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch(`${API_URL}${path}`, { ...options, headers });

  if (res.status === 401) {
    auth.clear();
    if (typeof window !== 'undefined' && !window.location.pathname.startsWith('/login')) {
      window.location.href = '/login';
    }
    throw new Error('Non authentifié');
  }

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = data?.message || `Erreur ${res.status}`;
    throw new Error(Array.isArray(msg) ? msg.join(', ') : msg);
  }
  return data as T;
}

export const api = {
  // Auth
  register: (body: any) => request('/auth/register', { method: 'POST', body: JSON.stringify(body) }),
  login: (body: any) => request('/auth/login', { method: 'POST', body: JSON.stringify(body) }),
  me: () => request('/auth/me'),

  // Dashboard
  dashboard: () => request('/dashboard'),

  // Modules (formation)
  modules: () => request('/modules'),
  module: (id: string) => request(`/modules/${id}`),
  submitQuiz: (id: string, answers: { questionId: string; optionIndex: number }[]) =>
    request(`/modules/${id}/quiz`, { method: 'POST', body: JSON.stringify({ answers }) }),

  // Simulation
  scenarios: () => request('/simulation/scenarios'),
  startSimulation: (scenarioId: string) =>
    request('/simulation/start', { method: 'POST', body: JSON.stringify({ scenarioId }) }),
  getSession: (id: string) => request(`/simulation/sessions/${id}`),
  sendMessage: (id: string, content: string) =>
    request(`/simulation/sessions/${id}/message`, {
      method: 'POST',
      body: JSON.stringify({ content }),
    }),
  endSession: (id: string) =>
    request(`/simulation/sessions/${id}/end`, { method: 'POST' }),

  // Certification
  eligibility: () => request('/certifications/eligibility'),
  issueCertificate: () => request('/certifications/issue', { method: 'POST' }),
  certificatePdfUrl: (id: string) => `${API_URL}/certifications/${id}/pdf`,
};
