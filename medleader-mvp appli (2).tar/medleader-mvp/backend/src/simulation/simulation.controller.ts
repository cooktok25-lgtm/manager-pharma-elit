import { Body, Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { CurrentUser } from '../auth/current-user.decorator';
import { SimulationService } from './simulation.service';
import { SendMessageDto, StartSimulationDto } from './dto/simulation.dto';

@UseGuards(JwtAuthGuard)
@Controller('simulation')
export class SimulationController {
  constructor(private simulationService: SimulationService) {}

  @Get('scenarios')
  scenarios() {
    return this.simulationService.listScenarios();
  }

  @Post('start')
  start(@CurrentUser() user: any, @Body() dto: StartSimulationDto) {
    return this.simulationService.startSession(user.id, dto.scenarioId);
  }

  @Get('sessions/:id')
  session(@CurrentUser() user: any, @Param('id') id: string) {
    return this.simulationService.getSession(user.id, id);
  }

  @Post('sessions/:id/message')
  sendMessage(
    @CurrentUser() user: any,
    @Param('id') id: string,
    @Body() dto: SendMessageDto,
  ) {
    return this.simulationService.sendMessage(user.id, id, dto.content);
  }

  @Post('sessions/:id/end')
  end(@CurrentUser() user: any, @Param('id') id: string) {
    return this.simulationService.endSession(user.id, id);
  }
}
