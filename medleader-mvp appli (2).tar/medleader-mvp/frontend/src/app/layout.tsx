import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'MedLeader — Académie des managers pharma',
  description: 'Formation, simulation et évaluation des managers pharmaceutiques',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}
