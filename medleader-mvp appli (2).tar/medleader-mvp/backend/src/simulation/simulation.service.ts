import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { LlmService } from './llm.service';

@Injectable()
export class SimulationService {
  constructor(private prisma: PrismaService, private llm: LlmService) {}

  async listScenarios() {
    const scenarios = await this.prisma.scenario.findMany({
      select: { id: true, slug: true, title: true, description: true, context: true },
    });
    return scenarios;
  }

  /**
   * Démarre une session : crée la session + persiste le message d'ouverture de l'IA.
   */
  async startSession(userId: string, scenarioId: string) {
    const scenario = await this.prisma.scenario.findUnique({ where: { id: scenarioId } });
    if (!scenario) throw new NotFoundException('Scénario introuvable');

    const session = await this.prisma.simulationSession.create({
      data: {
        userId,
        scenarioId,
        status: 'active',
        messages: {
          create: {
            position: 0,
            role: 'assistant',
            content: scenario.opener,
          },
        },
      },
      include: { messages: true, scenario: true },
    });

    return this.formatSession(session);
  }

  async getSession(userId: string, sessionId: string) {
    const session = await this.prisma.simulationSession.findUnique({
      where: { id: sessionId },
      include: {
        messages: { orderBy: { position: 'asc' } },
        scenario: true,
      },
    });
    if (!session) throw new NotFoundException('Session introuvable');
    if (session.userId !== userId) throw new ForbiddenException();
    return this.formatSession(session);
  }

  /**
   * Envoi d'un message utilisateur :
   * 1. Persiste le message user
   * 2. En PARALLÈLE : appelle l'IA pour role-play + appelle l'IA pour analyse
   * 3. Persiste la réponse IA + l'analyse sur le message user
   * 4. Met à jour le score moyen de la session
   */
  async sendMessage(userId: string, sessionId: string, content: string) {
    const session = await this.prisma.simulationSession.findUnique({
      where: { id: sessionId },
      include: {
        messages: { orderBy: { position: 'asc' } },
        scenario: true,
      },
    });
    if (!session) throw new NotFoundException('Session introuvable');
    if (session.userId !== userId) throw new ForbiddenException();
    if (session.status !== 'active') throw new ForbiddenException('Session terminée');

    const nextPosition = session.messages.length;

    // 1. Persiste user message (sans analyse pour l'instant)
    const userMsg = await this.prisma.simulationMessage.create({
      data: {
        sessionId,
        position: nextPosition,
        role: 'user',
        content,
      },
    });

    // History complet pour l'IA (incluant le message user qu'on vient d'ajouter)
    const history = [
      ...session.messages.map((m) => ({
        role: m.role as 'user' | 'assistant',
        content: m.content,
      })),
      { role: 'user' as const, content },
    ];

    // 2. Appels IA en parallèle
    const [aiReply, analysis] = await Promise.all([
      this.llm.generateRolePlayReply(session.scenario.systemPrompt, history),
      this.llm.analyzeUserResponse(
        `${session.scenario.title}\n${session.scenario.description}\n${session.scenario.context}`,
        session.messages.map((m) => ({
          role: m.role as 'user' | 'assistant',
          content: m.content,
        })),
        content,
      ),
    ]);

    // 3. Persiste analyse sur le message user
    const updatedUserMsg = await this.prisma.simulationMessage.update({
      where: { id: userMsg.id },
      data: {
        score: analysis.score,
        feedback: analysis.feedback,
        axes: analysis.axes as any,
      },
    });

    // 4. Persiste réponse IA
    const aiMsg = await this.prisma.simulationMessage.create({
      data: {
        sessionId,
        position: nextPosition + 1,
        role: 'assistant',
        content: aiReply,
      },
    });

    // 5. Recalcul score moyen de la session
    const allUserMessages = await this.prisma.simulationMessage.findMany({
      where: { sessionId, role: 'user', score: { not: null } },
      select: { score: true },
    });
    const avg =
      allUserMessages.reduce((acc, m) => acc + (m.score || 0), 0) /
      Math.max(1, allUserMessages.length);

    await this.prisma.simulationSession.update({
      where: { id: sessionId },
      data: { averageScore: Math.round(avg * 10) / 10 },
    });

    // Mise à jour du score global de l'utilisateur (moyenne pondérée simple)
    await this.recomputeGlobalScore(userId);

    return {
      userMessage: this.formatMessage(updatedUserMsg),
      aiMessage: this.formatMessage(aiMsg),
      sessionAverageScore: Math.round(avg * 10) / 10,
    };
  }

  async endSession(userId: string, sessionId: string) {
    const session = await this.prisma.simulationSession.findUnique({
      where: { id: sessionId },
    });
    if (!session) throw new NotFoundException('Session introuvable');
    if (session.userId !== userId) throw new ForbiddenException();

    return this.prisma.simulationSession.update({
      where: { id: sessionId },
      data: { status: 'ended', endedAt: new Date() },
    });
  }

  // ---------- Helpers ----------

  private async recomputeGlobalScore(userId: string) {
    // Score global = moyenne des averageScore des sessions x 10 (échelle 0-100)
    const sessions = await this.prisma.simulationSession.findMany({
      where: { userId, averageScore: { not: null } },
      select: { averageScore: true },
    });
    if (sessions.length === 0) return;
    const avg =
      sessions.reduce((a, s) => a + (s.averageScore || 0), 0) / sessions.length;
    await this.prisma.user.update({
      where: { id: userId },
      data: { globalScore: Math.round(avg * 10) },
    });
  }

  private formatSession(session: any) {
    return {
      id: session.id,
      status: session.status,
      averageScore: session.averageScore,
      scenario: {
        id: session.scenario.id,
        title: session.scenario.title,
        description: session.scenario.description,
        context: session.scenario.context,
      },
      messages: session.messages.map(this.formatMessage),
    };
  }

  private formatMessage(m: any) {
    return {
      id: m.id,
      position: m.position,
      role: m.role,
      content: m.content,
      score: m.score,
      feedback: m.feedback,
      axes: m.axes,
      createdAt: m.createdAt,
    };
  }
}
