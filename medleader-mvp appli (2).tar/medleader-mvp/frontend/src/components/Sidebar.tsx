'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { auth } from '@/lib/api';

const items = [
  { href: '/dashboard', label: 'Tableau de bord' },
  { href: '/simulation', label: 'Simulation IA' },
  { href: '/certification', label: 'Certification' },
];

export default function Sidebar({ user }: { user?: { firstName?: string; lastName?: string } }) {
  const path = usePathname();
  const router = useRouter();

  const logout = () => {
    auth.clear();
    router.replace('/login');
  };

  return (
    <aside className="w-full md:w-64 md:h-screen md:sticky md:top-0 bg-cream border-r border-border flex md:flex-col flex-row items-center md:items-stretch p-4 md:p-6 gap-3 md:gap-0">
      <div className="flex items-center gap-2 md:mb-10 shrink-0">
        <div className="w-9 h-9 bg-ink rounded flex items-center justify-center text-paper font-serif text-lg">
          M
        </div>
        <div className="hidden md:block">
          <div className="font-serif text-lg leading-none">MedLeader</div>
          <div className="text-[10px] text-ink/60 uppercase tracking-wider mt-0.5">
            Académie pharma
          </div>
        </div>
      </div>

      <nav className="flex md:flex-col flex-1 gap-1 md:gap-1 ml-auto md:ml-0">
        {items.map((item) => {
          const active = path?.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`px-3 py-2 rounded text-sm transition ${
                active
                  ? 'bg-ink text-paper font-medium'
                  : 'text-ink hover:bg-ink/5'
              }`}
            >
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="hidden md:block mt-auto pt-4 border-t border-border">
        {user && (
          <div className="text-xs text-ink/70 mb-2">
            <div className="font-medium text-ink">
              {user.firstName} {user.lastName}
            </div>
          </div>
        )}
        <button
          onClick={logout}
          className="text-xs text-copper hover:underline"
        >
          Déconnexion
        </button>
      </div>
    </aside>
  );
}
