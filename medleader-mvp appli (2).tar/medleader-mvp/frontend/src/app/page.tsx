'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { auth } from '@/lib/api';

export default function HomePage() {
  const router = useRouter();
  useEffect(() => {
    if (auth.getToken()) router.replace('/dashboard');
    else router.replace('/login');
  }, [router]);
  return (
    <div className="min-h-screen flex items-center justify-center text-ink">
      <p>Redirection...</p>
    </div>
  );
}
