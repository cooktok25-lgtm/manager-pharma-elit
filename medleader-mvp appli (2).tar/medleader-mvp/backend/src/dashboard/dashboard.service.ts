import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class DashboardService {
  constructor(private prisma: PrismaService) {}

  async getOverview(userId: string) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });

    const totalModules = await this.prisma.module.count();
    const completedModules = await this.prisma.moduleProgress.count({
      where: { userId, status: 'completed' },
    });

    const sessions = await this.prisma.simulationSession.findMany({
      where: { userId },
      select: { id: true, averageScore: true, status: true, createdAt: true, scenario: { select: { title: true } } },
      orderBy: { createdAt: 'desc' },
      take: 5,
    });

    const allUserMessages = await this.prisma.simulationMessage.findMany({
      where: {
        role: 'user',
        score: { not: null },
        session: { userId },
      },
      select: { axes: true },
    });

    // Moyennes par axe
    const axesSums = { leadership: 0, communication: 0, decision: 0 };
    let n = 0;
    allUserMessages.forEach((m) => {
      const a = m.axes as any;
      if (a && typeof a === 'object') {
        axesSums.leadership += Number(a.leadership || 0);
        axesSums.communication += Number(a.communication || 0);
        axesSums.decision += Number(a.decision || 0);
        n++;
      }
    });

    const skills = n > 0
      ? {
          leadership: Math.round((axesSums.leadership / n) * 10),
          communication: Math.round((axesSums.communication / n) * 10),
          decision: Math.round((axesSums.decision / n) * 10),
        }
      : { leadership: 0, communication: 0, decision: 0 };

    const progressionPct =
      totalModules > 0 ? Math.round((completedModules / totalModules) * 100) : 0;

    return {
      user: {
        firstName: user.firstName,
        lastName: user.lastName,
        goal: user.goal,
        level: user.level,
        globalScore: user.globalScore,
      },
      progressionPct,
      modulesCompleted: completedModules,
      modulesTotal: totalModules,
      simulationsCount: sessions.length,
      skills,
      recentSessions: sessions.map((s) => ({
        id: s.id,
        title: s.scenario.title,
        averageScore: s.averageScore,
        status: s.status,
        createdAt: s.createdAt,
      })),
    };
  }
}
