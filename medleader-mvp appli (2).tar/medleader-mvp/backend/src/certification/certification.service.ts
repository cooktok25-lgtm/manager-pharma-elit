import {
  Injectable,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import * as PDFKit from 'pdfkit';
import { createHmac } from 'crypto';

const ELIGIBILITY = {
  minModulesCompleted: 1,
  minSimulations: 2,
  minAverageScore: 7, // /10
};

@Injectable()
export class CertificationService {
  constructor(private prisma: PrismaService) {}

  /**
   * Vérifie l'éligibilité d'un utilisateur à la certification.
   */
  async getEligibility(userId: string) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user) throw new NotFoundException();

    const modulesCompleted = await this.prisma.moduleProgress.count({
      where: { userId, status: 'completed' },
    });

    const sessions = await this.prisma.simulationSession.findMany({
      where: { userId, averageScore: { not: null } },
      select: { averageScore: true },
    });

    const avg =
      sessions.length > 0
        ? sessions.reduce((a, s) => a + (s.averageScore || 0), 0) / sessions.length
        : 0;

    const requirements = [
      {
        key: 'modules',
        label: 'Modules complétés',
        current: modulesCompleted,
        required: ELIGIBILITY.minModulesCompleted,
        ok: modulesCompleted >= ELIGIBILITY.minModulesCompleted,
      },
      {
        key: 'simulations',
        label: 'Simulations réalisées',
        current: sessions.length,
        required: ELIGIBILITY.minSimulations,
        ok: sessions.length >= ELIGIBILITY.minSimulations,
      },
      {
        key: 'score',
        label: 'Score moyen simulations (/10)',
        current: Math.round(avg * 10) / 10,
        required: ELIGIBILITY.minAverageScore,
        ok: avg >= ELIGIBILITY.minAverageScore,
      },
    ];

    const eligible = requirements.every((r) => r.ok);

    // Cherche un certificat existant
    const existing = await this.prisma.certification.findFirst({
      where: { userId },
      orderBy: { issuedAt: 'desc' },
    });

    return {
      eligible,
      requirements,
      existing: existing
        ? {
            id: existing.id,
            certificateNo: existing.certificateNo,
            globalScore: existing.globalScore,
            issuedAt: existing.issuedAt,
          }
        : null,
    };
  }

  /**
   * Émet un certificat si l'utilisateur est éligible.
   */
  async issue(userId: string) {
    const eligibility = await this.getEligibility(userId);
    if (!eligibility.eligible) {
      throw new BadRequestException(
        'Vous ne remplissez pas encore les critères de certification',
      );
    }

    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    const modulesCompleted = await this.prisma.moduleProgress.count({
      where: { userId, status: 'completed' },
    });
    const simulationsCount = await this.prisma.simulationSession.count({
      where: { userId },
    });

    const certificateNo =
      'ML-' + Math.random().toString(36).substring(2, 10).toUpperCase();

    // Signature HMAC pour vérification publique
    const secret = process.env.JWT_SECRET || 'dev-secret-change-me';
    const payload = `${certificateNo}|${user.id}|${user.globalScore}`;
    const signatureHash = createHmac('sha256', secret)
      .update(payload)
      .digest('hex')
      .substring(0, 32);

    const cert = await this.prisma.certification.create({
      data: {
        userId,
        certificateNo,
        goal: user.goal,
        globalScore: user.globalScore,
        modulesCompleted,
        simulationsCount,
        signatureHash,
      },
    });

    return {
      id: cert.id,
      certificateNo: cert.certificateNo,
      globalScore: cert.globalScore,
      issuedAt: cert.issuedAt,
    };
  }

  /**
   * Génère le PDF du certificat à la volée et renvoie un Buffer.
   */
  async generatePdf(certId: string, userId: string): Promise<Buffer> {
    const cert = await this.prisma.certification.findUnique({
      where: { id: certId },
      include: { user: true },
    });
    if (!cert) throw new NotFoundException('Certificat introuvable');
    if (cert.userId !== userId) throw new NotFoundException();

    return new Promise((resolve, reject) => {
      const doc = new (PDFKit as any)({
        size: 'A4',
        layout: 'landscape',
        margins: { top: 60, bottom: 60, left: 60, right: 60 },
      });

      const chunks: Buffer[] = [];
      doc.on('data', (c) => chunks.push(c));
      doc.on('end', () => resolve(Buffer.concat(chunks)));
      doc.on('error', reject);

      // === Couleurs (cohérentes avec le frontend) ===
      const INK = '#1a1a17';
      const COPPER = '#b8551e';
      const FOREST = '#1f3d2e';
      const PAPER = '#f4efe6';

      const W = doc.page.width;
      const H = doc.page.height;

      // Fond papier
      doc.rect(0, 0, W, H).fill(PAPER);

      // Bordure double
      doc
        .rect(40, 40, W - 80, H - 80)
        .lineWidth(2)
        .stroke(INK);
      doc
        .rect(50, 50, W - 100, H - 100)
        .lineWidth(0.5)
        .stroke(INK);

      // Coins décoratifs cuivre
      const corner = 20;
      [
        [60, 60],
        [W - 80, 60],
        [60, H - 80],
        [W - 80, H - 80],
      ].forEach(([x, y], i) => {
        doc.lineWidth(2).strokeColor(COPPER);
        if (i === 0) {
          doc.moveTo(x, y + corner).lineTo(x, y).lineTo(x + corner, y).stroke();
        } else if (i === 1) {
          doc.moveTo(x, y).lineTo(x + corner, y).lineTo(x + corner, y + corner).stroke();
        } else if (i === 2) {
          doc.moveTo(x, y).lineTo(x, y + corner).lineTo(x + corner, y + corner).stroke();
        } else {
          doc.moveTo(x, y + corner).lineTo(x + corner, y + corner).lineTo(x + corner, y).stroke();
        }
      });

      // === En-tête ===
      doc
        .fillColor(COPPER)
        .font('Helvetica-Bold')
        .fontSize(10)
        .text('— MEDLEADER ACADEMY —', 0, 90, { align: 'center', characterSpacing: 4 });

      doc
        .fillColor(INK)
        .font('Helvetica-Oblique')
        .fontSize(16)
        .text('Certificat de compétence managériale', 0, 115, { align: 'center' });

      // Trait de séparation
      const sep1 = 160;
      doc
        .moveTo(W / 2 - 40, sep1)
        .lineTo(W / 2 + 40, sep1)
        .lineWidth(1)
        .strokeColor(INK)
        .stroke();

      // === Décerné à ===
      doc
        .fillColor(INK)
        .font('Helvetica')
        .fontSize(11)
        .text('Décerné à', 0, 180, { align: 'center' });

      doc
        .fillColor(INK)
        .font('Helvetica-Bold')
        .fontSize(48)
        .text(`${cert.user.firstName} ${cert.user.lastName}`, 0, 205, {
          align: 'center',
        });

      // === Description ===
      const goalLabel =
        cert.goal === 'manager' ? 'Manager Régional' : 'Directeur Régional';

      doc
        .fillColor(INK)
        .font('Helvetica')
        .fontSize(13)
        .text(
          `en reconnaissance des compétences managériales acquises\ndans le cadre du parcours `,
          0,
          280,
          { align: 'center', lineGap: 4 },
        );

      doc
        .fillColor(COPPER)
        .font('Helvetica-Bold')
        .fontSize(15)
        .text(goalLabel, 0, 322, { align: 'center' });

      doc
        .fillColor(INK)
        .font('Helvetica-Oblique')
        .fontSize(13)
        .text('et validées par évaluation IA multi-dimensionnelle.', 0, 348, {
          align: 'center',
        });

      // Trait de séparation bas
      const sep2 = 395;
      doc
        .moveTo(W / 2 - 40, sep2)
        .lineTo(W / 2 + 40, sep2)
        .lineWidth(1)
        .strokeColor(INK)
        .stroke();

      // === Pied : 3 colonnes ===
      const footY = 430;
      const colW = (W - 160) / 3;

      // Colonne 1 : Date
      doc
        .fillColor(COPPER)
        .font('Helvetica-Bold')
        .fontSize(8)
        .text('DATE D\'ÉMISSION', 80, footY, { width: colW, align: 'left', characterSpacing: 1.5 });
      doc
        .fillColor(INK)
        .font('Helvetica')
        .fontSize(13)
        .text(
          new Date(cert.issuedAt).toLocaleDateString('fr-FR', {
            day: 'numeric',
            month: 'long',
            year: 'numeric',
          }),
          80,
          footY + 16,
          { width: colW, align: 'left' },
        );

      // Colonne 2 : Numéro
      doc
        .fillColor(COPPER)
        .font('Helvetica-Bold')
        .fontSize(8)
        .text('N° CERTIFICAT', 80 + colW, footY, {
          width: colW,
          align: 'center',
          characterSpacing: 1.5,
        });
      doc
        .fillColor(INK)
        .font('Courier')
        .fontSize(13)
        .text(cert.certificateNo, 80 + colW, footY + 16, {
          width: colW,
          align: 'center',
        });

      // Colonne 3 : Score
      doc
        .fillColor(COPPER)
        .font('Helvetica-Bold')
        .fontSize(8)
        .text('SCORE FINAL', 80 + 2 * colW, footY, {
          width: colW,
          align: 'right',
          characterSpacing: 1.5,
        });
      doc
        .fillColor(FOREST)
        .font('Helvetica-Bold')
        .fontSize(20)
        .text(`${cert.globalScore}`, 80 + 2 * colW, footY + 14, {
          width: colW - 30,
          align: 'right',
        });
      doc
        .fillColor(INK)
        .font('Helvetica')
        .fontSize(11)
        .text('/100', 80 + 2 * colW, footY + 22, { width: colW, align: 'right' });

      // Signature de vérification
      doc
        .fillColor(INK)
        .font('Helvetica')
        .fontSize(7)
        .text(
          `Signature de vérification : ${cert.signatureHash}`,
          0,
          H - 70,
          { align: 'center' },
        );

      doc.end();
    });
  }
}
