import { Body, Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { CurrentUser } from '../auth/current-user.decorator';
import { ModulesService } from './modules.service';
import { SubmitQuizDto } from './dto/quiz.dto';

@UseGuards(JwtAuthGuard)
@Controller('modules')
export class ModulesController {
  constructor(private modulesService: ModulesService) {}

  @Get()
  list(@CurrentUser() user: any) {
    return this.modulesService.listModules(user.id);
  }

  @Get(':id')
  get(@Param('id') id: string, @CurrentUser() user: any) {
    return this.modulesService.getModule(id, user.id);
  }

  @Post(':id/quiz')
  submit(
    @Param('id') id: string,
    @CurrentUser() user: any,
    @Body() dto: SubmitQuizDto,
  ) {
    return this.modulesService.submitQuiz(id, user.id, dto);
  }
}
