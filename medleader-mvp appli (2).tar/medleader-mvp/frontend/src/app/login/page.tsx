'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { api, auth } from '@/lib/api';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('test@medleader.com');
  const [password, setPassword] = useState('password123');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res: any = await api.login({ email, password });
      auth.setToken(res.accessToken);
      router.replace('/dashboard');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-10 h-10 bg-ink rounded flex items-center justify-center text-paper font-serif text-xl">
            M
          </div>
          <div>
            <div className="font-serif text-xl">MedLeader</div>
            <div className="text-[10px] text-ink/60 uppercase tracking-wider">
              Académie des managers pharma
            </div>
          </div>
        </div>

        <h1 className="font-serif text-4xl mb-2">Bon retour.</h1>
        <p className="text-sm text-ink/60 mb-8">
          Connectez-vous pour reprendre votre parcours.
        </p>

        <form onSubmit={onSubmit} className="space-y-4">
          <div>
            <label className="block text-xs uppercase tracking-wider text-ink/60 mb-1.5">
              Email
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3 py-2.5 bg-cream border border-border rounded outline-none focus:border-ink transition"
            />
          </div>
          <div>
            <label className="block text-xs uppercase tracking-wider text-ink/60 mb-1.5">
              Mot de passe
            </label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3 py-2.5 bg-cream border border-border rounded outline-none focus:border-ink transition"
            />
          </div>

          {error && (
            <div className="px-3 py-2 bg-copper/10 text-copper text-sm rounded">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-ink text-paper py-3 rounded font-medium hover:bg-ink/90 transition disabled:opacity-50"
          >
            {loading ? 'Connexion...' : 'Se connecter'}
          </button>
        </form>

        <p className="text-sm text-ink/60 mt-6 text-center">
          Pas de compte ?{' '}
          <Link href="/register" className="text-copper hover:underline">
            Créer un compte
          </Link>
        </p>

        <div className="mt-8 p-3 bg-cream border border-border rounded text-xs text-ink/70">
          <strong>Compte de test pré-rempli :</strong>
          <br />
          test@medleader.com / password123
        </div>
      </div>
    </div>
  );
}
