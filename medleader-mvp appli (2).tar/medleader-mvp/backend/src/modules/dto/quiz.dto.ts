import { IsArray, IsString, IsInt, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';

class QuizAnswer {
  @IsString()
  questionId: string;

  @IsInt()
  optionIndex: number;
}

export class SubmitQuizDto {
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => QuizAnswer)
  answers: QuizAnswer[];
}
