'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import { api, auth } from '@/lib/api';
import Sidebar from '@/components/Sidebar';

export default function ModulePage() {
  const params = useParams();
  const router = useRouter();
  const id = params.id as string;

  const [module, setModule] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'content' | 'quiz'>('content');
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<any>(null);

  useEffect(() => {
    if (!auth.getToken()) {
      router.replace('/login');
      return;
    }
    api.module(id).then((m: any) => {
      setModule(m);
      setLoading(false);
    });
  }, [id, router]);

  const submitQuiz = async () => {
    setSubmitting(true);
    try {
      const res: any = await api.submitQuiz(
        id,
        Object.entries(answers).map(([questionId, optionIndex]) => ({
          questionId,
          optionIndex,
        })),
      );
      setResult(res);
    } catch (e: any) {
      alert(e.message);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading || !module) {
    return (
      <div className="min-h-screen flex items-center justify-center text-ink/60">
        Chargement...
      </div>
    );
  }

  // Rendu markdown très basique (titres, paragraphes)
  const renderContent = (text: string) => {
    return text.split('\n\n').map((block, i) => {
      if (block.startsWith('# ')) {
        return (
          <h1 key={i} className="font-serif text-3xl md:text-4xl mt-6 mb-3">
            {block.slice(2)}
          </h1>
        );
      }
      if (block.startsWith('## ')) {
        return (
          <h2 key={i} className="font-serif text-2xl mt-6 mb-2">
            {block.slice(3)}
          </h2>
        );
      }
      if (block.startsWith('### ')) {
        return (
          <h3 key={i} className="font-serif text-xl mt-4 mb-2">
            {block.slice(4)}
          </h3>
        );
      }
      if (block.startsWith('- ')) {
        return (
          <ul key={i} className="list-disc list-inside space-y-1 my-3">
            {block.split('\n').map((line, j) => (
              <li key={j}>{line.replace(/^- /, '').replace(/\*\*(.+?)\*\*/g, '$1')}</li>
            ))}
          </ul>
        );
      }
      // Paragraphe avec **gras**
      const parts = block.split(/(\*\*[^*]+\*\*)/g);
      return (
        <p key={i} className="my-3 leading-relaxed text-ink/85">
          {parts.map((p, k) =>
            p.startsWith('**') && p.endsWith('**') ? (
              <strong key={k} className="text-ink">{p.slice(2, -2)}</strong>
            ) : (
              <span key={k}>{p}</span>
            ),
          )}
        </p>
      );
    });
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar />
      <main className="flex-1 px-4 md:px-10 py-6 md:py-8 max-w-3xl">
        <Link href="/dashboard" className="text-sm text-copper hover:underline">
          ← Retour au tableau de bord
        </Link>

        <div className="mt-4 mb-6 pb-4 border-b border-border">
          <div className="text-[10px] uppercase tracking-widest text-copper mb-2">
            Niveau {module.level} · {module.durationMin} min
          </div>
          <h1 className="font-serif text-3xl md:text-4xl">{module.title}</h1>
          <p className="text-ink/60 text-sm mt-2">{module.description}</p>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 border-b border-border">
          {(['content', 'quiz'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`px-4 py-2 text-sm border-b-2 -mb-px transition ${
                tab === t
                  ? 'border-ink text-ink font-medium'
                  : 'border-transparent text-ink/60 hover:text-ink'
              }`}
            >
              {t === 'content' ? 'Contenu' : `Quiz (${module.questions.length})`}
            </button>
          ))}
        </div>

        {/* Contenu */}
        {tab === 'content' && (
          <article className="prose-content">
            {renderContent(module.content)}
            <div className="mt-8">
              <button
                onClick={() => setTab('quiz')}
                className="bg-ink text-paper px-5 py-3 rounded font-medium hover:bg-ink/90 transition"
              >
                Passer au quiz →
              </button>
            </div>
          </article>
        )}

        {/* Quiz */}
        {tab === 'quiz' && !result && (
          <div className="space-y-6">
            {module.questions.map((q: any, qi: number) => (
              <div key={q.id} className="bg-cream border border-border p-5">
                <div className="text-[10px] uppercase tracking-wider text-copper mb-2">
                  Question {qi + 1} / {module.questions.length}
                </div>
                <p className="font-serif text-lg mb-4">{q.question}</p>
                <div className="space-y-2">
                  {q.options.map((o: any, oi: number) => (
                    <label
                      key={oi}
                      className={`flex items-center gap-3 p-3 border rounded cursor-pointer transition ${
                        answers[q.id] === oi
                          ? 'border-ink bg-ink/5'
                          : 'border-border hover:border-ink/40'
                      }`}
                    >
                      <input
                        type="radio"
                        name={q.id}
                        checked={answers[q.id] === oi}
                        onChange={() => setAnswers({ ...answers, [q.id]: oi })}
                        className="accent-ink"
                      />
                      <span className="text-sm">{o.label}</span>
                    </label>
                  ))}
                </div>
              </div>
            ))}

            <button
              onClick={submitQuiz}
              disabled={
                submitting || Object.keys(answers).length < module.questions.length
              }
              className="w-full bg-ink text-paper py-3 rounded font-medium hover:bg-ink/90 transition disabled:opacity-50"
            >
              {submitting ? 'Validation...' : 'Valider mes réponses'}
            </button>
          </div>
        )}

        {result && (
          <div className="bg-cream border border-border p-6 text-center">
            <div className="text-[10px] uppercase tracking-widest text-copper mb-2">
              Résultat
            </div>
            <div
              className={`font-serif text-7xl mb-2 ${
                result.passed ? 'text-forest' : 'text-copper'
              }`}
            >
              {result.score}
              <span className="text-2xl text-ink/60">/100</span>
            </div>
            <p className="text-lg mb-4">
              {result.passed ? '✓ Module validé !' : 'Module non validé (≥ 70 requis)'}
            </p>
            <p className="text-sm text-ink/70 mb-6">
              {result.correctCount}/{result.totalQuestions} bonnes réponses
            </p>
            <div className="flex gap-2 justify-center">
              <button
                onClick={() => {
                  setResult(null);
                  setAnswers({});
                }}
                className="px-4 py-2 border border-ink rounded text-sm hover:bg-ink hover:text-paper transition"
              >
                Recommencer le quiz
              </button>
              <Link
                href="/dashboard"
                className="px-4 py-2 bg-ink text-paper rounded text-sm hover:bg-ink/90 transition"
              >
                Retour dashboard
              </Link>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
