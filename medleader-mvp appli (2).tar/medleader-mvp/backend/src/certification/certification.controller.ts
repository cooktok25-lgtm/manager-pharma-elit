import {
  Controller,
  Get,
  Param,
  Post,
  Res,
  UseGuards,
} from '@nestjs/common';
import { Response } from 'express';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { CurrentUser } from '../auth/current-user.decorator';
import { CertificationService } from './certification.service';

@UseGuards(JwtAuthGuard)
@Controller('certifications')
export class CertificationController {
  constructor(private certService: CertificationService) {}

  @Get('eligibility')
  eligibility(@CurrentUser() user: any) {
    return this.certService.getEligibility(user.id);
  }

  @Post('issue')
  issue(@CurrentUser() user: any) {
    return this.certService.issue(user.id);
  }

  @Get(':id/pdf')
  async pdf(
    @CurrentUser() user: any,
    @Param('id') id: string,
    @Res() res: Response,
  ) {
    const buffer = await this.certService.generatePdf(id, user.id);
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="certificat-medleader-${id.substring(0, 8)}.pdf"`,
    );
    res.setHeader('Content-Length', buffer.length);
    res.end(buffer);
  }
}
