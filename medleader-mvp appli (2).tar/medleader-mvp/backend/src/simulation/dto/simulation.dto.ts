import { IsString, IsNotEmpty, MaxLength } from 'class-validator';

export class StartSimulationDto {
  @IsString()
  @IsNotEmpty()
  scenarioId: string;
}

export class SendMessageDto {
  @IsString()
  @IsNotEmpty()
  @MaxLength(2000)
  content: string;
}
