import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { PrismaModule } from './prisma/prisma.module';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { ModulesModule } from './modules/modules.module';
import { SimulationModule } from './simulation/simulation.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { CertificationModule } from './certification/certification.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    PrismaModule,
    AuthModule,
    UsersModule,
    ModulesModule,
    SimulationModule,
    DashboardModule,
    CertificationModule,
  ],
})
export class AppModule {}
