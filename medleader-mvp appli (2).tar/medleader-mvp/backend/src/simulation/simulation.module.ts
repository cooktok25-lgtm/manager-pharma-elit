import { Module } from '@nestjs/common';
import { SimulationController } from './simulation.controller';
import { SimulationService } from './simulation.service';
import { LlmService } from './llm.service';

@Module({
  controllers: [SimulationController],
  providers: [SimulationService, LlmService],
})
export class SimulationModule {}
